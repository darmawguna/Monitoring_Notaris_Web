<?php
    $record = $getRecord();
?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    
    <div class="space-y-4 p-4 border rounded-lg">
        <h3 class="font-bold text-lg">Data Penjual</h3>
        <!--[if BLOCK]><![endif]--><?php if($record->penjual_data): ?>
            <div>
                <p class="text-sm font-medium text-gray-500">Nama</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->penjual_data['nama'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">NIK</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->penjual_data['nik'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">No. Telp</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->penjual_data['telp'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Alamat</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->penjual_data['alamat'] ?? '-'); ?></p>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Tidak ada data.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div class="space-y-4 p-4 border rounded-lg">
        <h3 class="font-bold text-lg">Data Pembeli</h3>
        <!--[if BLOCK]><![endif]--><?php if($record->pembeli_data): ?>
            <div>
                <p class="text-sm font-medium text-gray-500">Nama</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pembeli_data['nama'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">NIK</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pembeli_data['nik'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">No. Telp</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pembeli_data['telp'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Alamat</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pembeli_data['alamat'] ?? '-'); ?></p>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Tidak ada data.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div class="space-y-4 p-4 border rounded-lg">
        <h3 class="font-bold text-lg">Pihak Persetujuan</h3>
        <!--[if BLOCK]><![endif]--><?php if($record->pihak_persetujuan_data): ?>
             <div>
                <p class="text-sm font-medium text-gray-500">Nama</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pihak_persetujuan_data['nama'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">NIK</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pihak_persetujuan_data['nik'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">No. Telp</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pihak_persetujuan_data['telp'] ?? '-'); ?></p>
            </div>
            <div>
                <p class="text-sm font-medium text-gray-500">Alamat</p>
                <p class="text-base text-gray-900 dark:text-white"><?php echo e($record->pihak_persetujuan_data['alamat'] ?? '-'); ?></p>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Tidak ada data.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH D:\Project-WEB\Notaris -Pak Hendy\notarisku\resources\views/filament/infolists/sections/jual-beli-section.blade.php ENDPATH**/ ?>