<?php
    $record = $getRecord();
    // 1. Definisikan "kamus" atau pemetaan untuk tipe sertifikat
    $tipeSertifikatMap = [
        'hm' => 'Hak Milik (HM)',
        'hgb' => 'Hak Guna Bangunan (HGB)',
        'hp' => 'Hak Pakai (HP)',
        'hu' => 'Hak Guna Usaha (HU)',
    ];
?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div>
        <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Nomor Sertifikat</p>
        <p class="mt-1 text-base text-gray-900 dark:text-white"><?php echo e($record->sertifikat_nomor ?? '-'); ?></p>
    </div>
    <div>
        <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Luas</p>
        <p class="mt-1 text-base text-gray-900 dark:text-white"><?php echo e($record->sertifikat_luas ? $record->sertifikat_luas . ' m²' : '-'); ?></p>
    </div>
    <div>
        <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Jenis</p>
        <p class="mt-1 text-base text-gray-900 dark:text-white"><?php echo e(Str::ucfirst($record->sertifikat_jenis) ?? '-'); ?></p>
    </div>
    
    
    <div>
        <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Tipe</p>
        
        <p class="mt-1 text-base text-gray-900 dark:text-white">
            <?php echo e($tipeSertifikatMap[$record->sertifikat_tipe] ?? Str::ucfirst($record->sertifikat_tipe) ?? '-'); ?>

        </p>
    </div>
    
    
    <div>
        <p class="text-sm font-medium text-gray-500 uppercase tracking-wider">Nilai Transaksi</p>
        <p class="mt-1 text-base text-gray-900 dark:text-white"><?php echo e($record->nilai_transaksi ? 'Rp ' . number_format($record->nilai_transaksi, 0, ',', '.') : '-'); ?></p>
    </div>
</div>
<?php /**PATH D:\Project-WEB\Notaris -Pak Hendy\notarisku\resources\views/filament/infolists/sections/sertifikat-section.blade.php ENDPATH**/ ?>